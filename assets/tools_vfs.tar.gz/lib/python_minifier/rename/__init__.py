from python_minifier.rename.bind_names import bind_names
from python_minifier.rename.mapper import add_namespace
from python_minifier.rename.rename_literals import rename_literals
from python_minifier.rename.renamer import rename
from python_minifier.rename.resolve_names import resolve_names
from python_minifier.rename.util import allow_rename_locals, allow_rename_globals
